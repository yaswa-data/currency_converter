const fromCurrency = document.getElementById("fromCurrency");
const toCurrency = document.getElementById("toCurrency");
const currencies = ["USD", "EUR", "INR", "GBP", "JPY", "CAD", "AUD"];

currencies.forEach((currency) => {
    let option1 = document.createElement("option");
    let option2 = document.createElement("option");
    option1.value = option2.value = currency;
    option1.text = option2.text = currency;
    fromCurrency.appendChild(option1);
    toCurrency.appendChild(option2);
});

fromCurrency.value = "USD";
toCurrency.value = "INR";

async function convertCurrency() {
    const amount = document.getElementById("amount").value;
    const from = fromCurrency.value;
    const to = toCurrency.value;

    if (!amount || isNaN(amount)) {
        alert("Enter a valid number");
        return;
    }

    const res = await fetch("/convert", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ amount, from, to })
    });

    const data = await res.json();
    const resultBox = document.getElementById("result");
    if (data.result) {
        resultBox.innerText = data.result;
    } else {
        resultBox.innerText = "Error converting currencies";
    }
}
