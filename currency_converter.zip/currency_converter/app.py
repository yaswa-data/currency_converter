from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    converted_amount = None
    currencies = ['USD', 'INR', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CNY']
    
    if request.method == 'POST':
        try:
            amount = float(request.form['amount'])
            from_currency = request.form['from_currency']
            to_currency = request.form['to_currency']

            url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
            response = requests.get(url)
            data = response.json()

            if to_currency in data['rates']:
                rate = data['rates'][to_currency]
                converted_amount = round(amount * rate, 2)
            else:
                converted_amount = "Invalid currency selected."
        except Exception as e:
            converted_amount = f"Error: {str(e)}"
    
    return render_template('index.html', currencies=currencies, converted_amount=converted_amount)

# ✅ This is what runs the server
if __name__ == '__main__':
    app.run(debug=True)
